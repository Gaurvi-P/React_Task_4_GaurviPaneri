import React from "react";
import PostData from "./components/PostData";
function App() {
 

  return (
    <>
      <PostData/>
    </>
  )
}

export default App
